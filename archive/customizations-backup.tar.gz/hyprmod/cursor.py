"""Cursor theme selection page — thumbnails, size, live apply."""

import subprocess
from collections.abc import Iterator
from typing import NamedTuple, cast

from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk, Pango
from hyprland_socket import HyprlandError, set_cursor

from hyprmod.core import config
from hyprmod.core.cursor_themes import CursorTheme, discover
from hyprmod.core.env_vars import RESERVED_NAMES as _MANAGED_VARS
from hyprmod.core.env_vars import parse_env_lines
from hyprmod.core.pending import PendingChange
from hyprmod.core.undo import CursorUndoEntry
from hyprmod.core.xcursor import crop_to_content, load_pointer, pad_to_square, scale_nearest
from hyprmod.pages.section import SectionPage
from hyprmod.ui.icons import CURSOR_ICON
from hyprmod.ui.managed_row import ManagedRow, make_combo_row
from hyprmod.ui.timer import Timer

# Theme- vs. size-flavoured cursor env vars. Membership in either tuple
# determines how a parsed value is interpreted (string vs. integer);
# the *union* is the broader contract this page exposes to the env-vars
# page via :data:`hyprmod.core.env_vars.RESERVED_NAMES` (re-exported
# above as ``_MANAGED_VARS``). Keep the per-flavour tuples a strict
# subset of ``_MANAGED_VARS`` if either side ever grows.
_THEME_VARS = ("XCURSOR_THEME", "HYPRCURSOR_THEME")
_SIZE_VARS = ("XCURSOR_SIZE", "HYPRCURSOR_SIZE")
_SYSTEM_DEFAULT = "__system_default__"
_THUMB_SIZE = 24
_DEFAULT_SIZE = 24


class _State(NamedTuple):
    theme: str  # theme name, or _SYSTEM_DEFAULT
    size: int


class _ThemeItem(GObject.Object):
    """GObject wrapper so themes can live in a Gio.ListStore."""

    __gtype_name__ = "HyprmodCursorThemeItem"

    def __init__(self, theme: CursorTheme | None, *, missing_name: str = ""):
        super().__init__()
        self.theme = theme  # None for "System default" or missing themes
        self.missing_name = missing_name  # Name from config that's not installed


def _theme_label(item: "_ThemeItem") -> str:
    if item.missing_name:
        return f"{item.missing_name}  (not installed)"
    theme = item.theme
    if theme is None:
        return "System default"
    suffix = {
        (True, True): "  (XCursor + Hyprcursor)",
        (False, True): "  (Hyprcursor)",
    }.get((theme.has_xcursor, theme.has_hyprcursor), "")
    return theme.display_name + suffix


def _run(*args: str) -> None:
    """Best-effort subprocess call (never raises)."""
    try:
        subprocess.run(args, check=False, capture_output=True, timeout=2)
    except (OSError, subprocess.SubprocessError):
        pass


class CursorPage(SectionPage):
    """Manages the cursor theme picker widget on the Cursor page."""

    def __init__(
        self,
        window,
        on_dirty_changed=None,
        push_undo=None,
        saved_sections: dict | None = None,
    ):
        super().__init__(window, on_dirty_changed, push_undo)
        self._themes: list[CursorTheme] = discover()
        self._thumb_cache: dict[str, Gdk.Texture | None] = {}

        self._baseline = self._parse_env(saved_sections or {})
        self._current = _State(self._baseline.theme, self._baseline.size)
        self._last_pushed = _State(self._current.theme, self._current.size)

        self._model: Gio.ListStore | None = None
        self._size_adjustment: Gtk.Adjustment | None = None
        self._size_spin: Gtk.SpinButton | None = None
        self._theme_row: Adw.ComboRow | None = None
        self._field: ManagedRow | None = None
        self._apply_timer = Timer()
        # Handler ids of the user-interaction signals so silent setters
        # can block them around programmatic widget mutation (avoiding
        # the boolean-flag anti-pattern).
        self._theme_handler_id: int = 0
        self._size_handler_id: int = 0

    @staticmethod
    def _parse_env(sections: dict[str, list[str]]) -> _State:
        theme, size = _SYSTEM_DEFAULT, _DEFAULT_SIZE
        for ev in parse_env_lines(sections.get(config.KEYWORD_ENV, [])):
            if ev.name in _THEME_VARS and ev.value:
                theme = ev.value
            elif ev.name in _SIZE_VARS and ev.value.isdigit():
                size = int(ev.value)
        return _State(theme, size)

    # ── Widget ──

    def build_widget(self) -> Adw.PreferencesGroup:
        group = Adw.PreferencesGroup(
            title="Theme",
            description=(
                "Applies instantly to Hyprland and GTK apps. "
                "Other apps pick up changes on relaunch."
            ),
        )

        self._model = Gio.ListStore.new(_ThemeItem)
        self._model.append(_ThemeItem(None))
        for theme in self._themes:
            self._model.append(_ThemeItem(theme))

        # If the saved theme isn't installed, keep a placeholder item so the
        # user can see what's configured and revert without losing the name.
        known = {t.name for t in self._themes}
        baseline = self._baseline.theme
        if baseline != _SYSTEM_DEFAULT and baseline not in known:
            self._model.append(_ThemeItem(None, missing_name=baseline))

        factory = Gtk.SignalListItemFactory()
        factory.connect("setup", self._factory_setup)
        factory.connect("bind", self._factory_bind)

        row = make_combo_row(
            "Cursor",
            subtitle="Theme and size",
            model=self._model,
            factory=factory,
            selected=self._index_for(self._current.theme),
        )
        self._theme_handler_id = row.connect("notify::selected", self._on_theme_selected)
        self._theme_row = row

        self._size_adjustment = Gtk.Adjustment(
            value=self._current.size, lower=8, upper=128, step_increment=1, page_increment=4
        )
        self._size_spin = Gtk.SpinButton(adjustment=self._size_adjustment, digits=0)
        self._size_spin.set_valign(Gtk.Align.CENTER)
        self._size_spin.set_sensitive(self._current.theme != _SYSTEM_DEFAULT)
        self._size_spin.set_tooltip_text("Cursor size (pixels)")
        self._size_handler_id = self._size_spin.connect("value-changed", self._on_size_changed)
        row.add_suffix(self._size_spin)

        self._field = ManagedRow(
            row,
            default=(_SYSTEM_DEFAULT, _DEFAULT_SIZE),
            baseline=(self._baseline.theme, self._baseline.size),
            get_value=lambda: (self._current.theme, self._current.size),
            set_value_silent=self._set_state_silent,
            on_value_set=lambda _v: self._changed(),
        )
        group.add(row)

        return group

    def _index_for(self, theme_name: str) -> int:
        # Model has "System default" at index 0, installed themes at 1+,
        # and optionally a trailing placeholder for an uninstalled baseline.
        if theme_name == _SYSTEM_DEFAULT:
            return 0
        for i, t in enumerate(self._themes):
            if t.name == theme_name:
                return i + 1
        if self._model is not None:
            last = self._model.get_n_items() - 1
            if last > 0:
                item = cast(_ThemeItem, self._model.get_item(last))
                if item.missing_name == theme_name:
                    return last
        return 0

    # ── Factory (thumbnail + label) ──

    def _factory_setup(self, _factory, list_item):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_valign(Gtk.Align.CENTER)
        image = Gtk.Image(pixel_size=_THUMB_SIZE, valign=Gtk.Align.CENTER)
        label = Gtk.Label(xalign=0.0, ellipsize=Pango.EllipsizeMode.END, valign=Gtk.Align.CENTER)
        box.append(image)
        box.append(label)
        list_item.set_child(box)

    def _factory_bind(self, _factory, list_item):
        item = cast(_ThemeItem, list_item.get_item())
        box = cast(Gtk.Box, list_item.get_child())
        image = cast(Gtk.Image, box.get_first_child())
        label = cast(Gtk.Label, image.get_next_sibling())
        label.set_label(_theme_label(item))
        texture = self._get_thumb(item.theme) if item.theme else None
        if texture is not None:
            image.set_from_paintable(texture)
        elif item.missing_name:
            image.set_from_icon_name("dialog-warning-symbolic")
        else:
            image.clear()

    def _get_thumb(self, theme: CursorTheme) -> Gdk.Texture | None:
        if theme.name in self._thumb_cache:
            return self._thumb_cache[theme.name]

        texture: Gdk.Texture | None = None
        img = load_pointer(theme.path, _THUMB_SIZE * 2)
        if img is not None:
            img = scale_nearest(pad_to_square(crop_to_content(img)), _THUMB_SIZE)
            texture = Gdk.MemoryTexture.new(
                img.width,
                img.height,
                Gdk.MemoryFormat.B8G8R8A8_PREMULTIPLIED,
                GLib.Bytes.new(img.bgra),
                img.width * 4,
            )
        self._thumb_cache[theme.name] = texture
        return texture

    # ── Silent setter (used by ManagedRow discard/reset + restore_snapshot) ──

    def _set_state_silent(self, value: tuple[str, int]) -> None:
        theme, size = value
        self._current = _State(theme, size)
        if self._theme_row is not None:
            self._theme_row.handler_block(self._theme_handler_id)
            try:
                self._theme_row.set_selected(self._index_for(theme))
            finally:
                self._theme_row.handler_unblock(self._theme_handler_id)
        if self._size_spin is not None and self._size_adjustment is not None:
            self._size_spin.handler_block(self._size_handler_id)
            try:
                self._size_adjustment.set_value(size)
            finally:
                self._size_spin.handler_unblock(self._size_handler_id)
            self._size_spin.set_sensitive(theme != _SYSTEM_DEFAULT)

    # ── Callbacks ──

    def _on_theme_selected(self, row, _pspec):
        if self._model is None:
            return
        item = cast(_ThemeItem, self._model.get_item(row.get_selected()))
        if item.theme:
            new_theme = item.theme.name
        elif item.missing_name:
            new_theme = item.missing_name
        else:
            new_theme = _SYSTEM_DEFAULT
        if new_theme == self._current.theme:
            return
        self._current = self._current._replace(theme=new_theme)
        if self._size_spin is not None:
            self._size_spin.set_sensitive(new_theme != _SYSTEM_DEFAULT)
        self._changed()

    def _on_size_changed(self, spin):
        new_size = int(spin.get_value())
        if new_size == self._current.size:
            return
        self._current = self._current._replace(size=new_size)
        self._changed()

    def _changed(self) -> None:
        if self._push_undo:
            self._push_undo(
                CursorUndoEntry(
                    old_theme=self._last_pushed.theme,
                    old_size=self._last_pushed.size,
                    new_theme=self._current.theme,
                    new_size=self._current.size,
                )
            )
            self._last_pushed = _State(self._current.theme, self._current.size)
        if self._field is not None:
            self._field.refresh()
        self._schedule_apply()
        self._notify_dirty()

    # ── Live apply (debounced) ──

    def _schedule_apply(self):
        self._apply_timer.schedule(150, self._apply_now)

    def _apply_now(self) -> bool:
        if self._current.theme == _SYSTEM_DEFAULT:
            return GLib.SOURCE_REMOVE
        theme, size = self._current.theme, self._current.size
        try:
            set_cursor(theme, size)
        except HyprlandError:
            pass
        _run("gsettings", "set", "org.gnome.desktop.interface", "cursor-theme", theme)
        _run("gsettings", "set", "org.gnome.desktop.interface", "cursor-size", str(size))
        _run("dconf", "write", "/org/gnome/desktop/interface/cursor-theme", f"'{theme}'")
        _run("dconf", "write", "/org/gnome/desktop/interface/cursor-size", str(size))

        # Synchronize GTK 3 & GTK 4 settings.ini so cursor changes persist across apps
        from pathlib import Path
        import re
        home = Path.home()
        for p in (home / ".config/gtk-3.0/settings.ini", home / ".config/gtk-4.0/settings.ini"):
            if p.is_file():
                try:
                    text = p.read_text(encoding="utf-8")
                    text = re.sub(r"^(gtk-cursor-theme-name=).*", rf"\g<1>{theme}", text, flags=re.MULTILINE)
                    text = re.sub(r"^(gtk-cursor-theme-size=).*", rf"\g<1>{size}", text, flags=re.MULTILINE)
                    p.write_text(text, encoding="utf-8")
                except OSError:
                    pass

        # Synchronize xsettingsd
        xs = home / ".config/xsettingsd/xsettingsd.conf"
        if xs.is_file():
            try:
                text = xs.read_text(encoding="utf-8")
                text = re.sub(r'^(Gtk/CursorThemeName\s+).*', rf'\g<1>"{theme}"', text, flags=re.MULTILINE)
                text = re.sub(r'^(Gtk/CursorThemeSize\s+).*', rf'\g<1>{size}', text, flags=re.MULTILINE)
                xs.write_text(text, encoding="utf-8")
                _run("killall", "-HUP", "xsettingsd")
            except OSError:
                pass

        # Synchronize default icon themes for X11 / XWayland fallbacks
        for idt in (home / ".icons/default/index.theme", home / ".local/share/icons/default/index.theme"):
            try:
                idt.parent.mkdir(parents=True, exist_ok=True)
                idt.write_text(f"[Icon Theme]\nName=Default\nComment=Default Cursor Theme\nInherits={theme}\n", encoding="utf-8")
            except OSError:
                pass

        # Synchronize nwg-look settings if present
        nwg = home / ".local/share/nwg-look/gsettings"
        if nwg.is_file():
            try:
                text = nwg.read_text(encoding="utf-8")
                text = re.sub(r"^(cursor-theme=).*", rf"\g<1>{theme}", text, flags=re.MULTILINE)
                text = re.sub(r"^(cursor-size=).*", rf"\g<1>{size}", text, flags=re.MULTILINE)
                nwg.write_text(text, encoding="utf-8")
            except OSError:
                pass

        # Hide then restore this window's cursor so Hyprland sees a shape
        # change and repaints with the just-applied theme.
        self._window.set_cursor(Gdk.Cursor.new_from_name("none", None))
        GLib.timeout_add(30, lambda: self._window.set_cursor(None) or False)
        return GLib.SOURCE_REMOVE

    # ── SectionPage protocol ──

    def is_dirty(self) -> bool:
        return self._current != self._baseline

    def mark_saved(self) -> None:
        self._baseline = _State(self._current.theme, self._current.size)
        self._last_pushed = _State(self._current.theme, self._current.size)
        if self._field is not None:
            self._field.set_baseline((self._baseline.theme, self._baseline.size))

    def discard(self) -> None:
        self.restore_snapshot(self._baseline.theme, self._baseline.size)

    def iter_pending_changes(self) -> Iterator[PendingChange]:
        if not self.is_dirty():
            return
        diffs: list[str] = []
        if self._baseline.theme != self._current.theme:
            diffs.append(
                f"theme {self._theme_label(self._baseline.theme)} → "
                f"{self._theme_label(self._current.theme)}"
            )
        if self._baseline.size != self._current.size:
            diffs.append(f"size {self._baseline.size}px → {self._current.size}px")
        yield PendingChange(
            category="Cursor",
            title="Cursor theme",
            subtitle=" · ".join(diffs) if diffs else "updated",
            kind="modified",
            revert=self.discard,
            navigate_to="cursor",
            icon=CURSOR_ICON,
        )

    @staticmethod
    def _theme_label(theme: str) -> str:
        # Avoid leaking the internal sentinel into UI strings.
        return "System default" if theme.startswith("__") else theme

    def restore_snapshot(self, theme: str, size: int) -> None:
        """Set state + UI to (theme, size) without pushing an undo entry."""
        self._set_state_silent((theme, size))
        self._last_pushed = _State(theme, size)
        if self._field is not None:
            self._field.refresh()
        self._notify_dirty()
        self._schedule_apply()

    def reload_from_saved(self, saved_sections: dict[str, list[str]]) -> None:
        """Re-read baseline from config (e.g. after profile switch)."""
        self._baseline = self._parse_env(saved_sections)
        if self._field is not None:
            self._field.set_baseline((self._baseline.theme, self._baseline.size))
        self.restore_snapshot(self._baseline.theme, self._baseline.size)

    def get_env_lines(self) -> list[str]:
        """Return env= lines for the cursor vars.

        When a theme is set, size is always emitted alongside — otherwise apps
        that don't assume the same default size (e.g. JetBrains IDEs) render
        the cursor at their own fallback. When only size differs from the
        default, emit just ``XCURSOR_SIZE``.
        """
        theme_set = self._current.theme != _SYSTEM_DEFAULT
        size_set = self._current.size != _DEFAULT_SIZE
        if not theme_set and not size_set:
            return []

        theme = next((t for t in self._themes if t.name == self._current.theme), None)
        name, size = self._current.theme, str(self._current.size)
        want_xcursor = theme is None or theme.has_xcursor
        want_hyprcursor = theme is not None and theme.has_hyprcursor
        emit_size = theme_set or size_set

        lines: list[str] = []
        if theme_set and want_xcursor:
            lines.append(f"env = XCURSOR_THEME,{name}")
        if emit_size and want_xcursor:
            lines.append(f"env = XCURSOR_SIZE,{size}")
        if theme_set and want_hyprcursor:
            lines.append(f"env = HYPRCURSOR_THEME,{name}")
        if emit_size and want_hyprcursor:
            lines.append(f"env = HYPRCURSOR_SIZE,{size}")
        return lines

    @staticmethod
    def has_managed_env(sections: dict[str, list[str]]) -> bool:
        """True if config has any of our managed env vars."""
        return any(
            ev.name in _MANAGED_VARS for ev in parse_env_lines(sections.get(config.KEYWORD_ENV, []))
        )

    @staticmethod
    def get_search_entries() -> list[dict]:
        """Entries for the global search page."""
        return [
            {
                "key": "cursor_theme",
                "label": "Cursor",
                "description": "Cursor theme and size",
                "_group_id": "cursor",
                "_group_label": "Cursor",
                "_section_label": "Theme",
            },
        ]
